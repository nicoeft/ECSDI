# Puertos utilizados
- 9000 SimpleDirectoryService
- 9010 AgenteCliente
- 9011 AgenteMostrarProductos
- 9012 AgenteVentaProductos
- 9013 AgenteLogistico
- 9014 AgenteAlmacen
- 9015 AgenteRecomendador
- 9016 AgenteProductosExternos
- 9017 AgenteDevoluciones
- 9030 al 9039 AgenteTransportista
- 9040 AgenteVendedorExterno


# Orden de los agentes:
- SimpleDirectoryService.py
- AgenteMostrarProductos.py
- AgenteLogistico.py
- AgenteVentaProductos.py
- AgenteAlmacen.py
- AgenteTransportista1.py
- AgenteCliente.py